var builder = WebApplication.CreateBuilder(args);

// Add services to the container (this is like ConfigureServices in old Startup.cs)
builder.Services.AddControllersWithViews();

var app = builder.Build();

// Configure the HTTP request pipeline (this is like Configure in old Startup.cs)
if (app.Environment.IsDevelopment())
{
    app.UseDeveloperExceptionPage();
}
else
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();