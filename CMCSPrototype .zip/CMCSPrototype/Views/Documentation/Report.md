# Report: Design and Prototype for Contract Monthly Claim System (CMCS)

The Contract Monthly Claim System (CMCS) is a .NET Core web application aimed at streamlining monthly claim submissions and approvals for independent contractor (IC) lecturers. For this prototype, I selected ASP.NET Core MVC as the framework for the GUI because it promotes separation of concerns (Model for data, View for UI, Controller for logic), supports responsive web design via Bootstrap, and integrates seamlessly with Entity Framework Core for future database needs. This choice ensures scalability and aligns with industry standards for web-based administrative tools. The database structure is designed using a relational model with SQL Server in mind, featuring key entities such as Lecturer (attributes: LecturerID, Name, Email, PasswordHash), Claim (ClaimID, LecturerID, HoursWorked, HourlyRate, TotalAmount, Status, Notes, SubmissionDate), Document (DocumentID, ClaimID, FilePath, FileName), and Approval (ApprovalID, ClaimID, ApproverID, ApproverRole, IsApproved, Comments, ApprovalDate). Relationships include one-to-many (Lecturer to Claims) and one-to-one (Claim to Approval), ensuring data integrity through foreign keys.

The GUI layout emphasizes intuitiveness: a central dashboard with role-based links (e.g., "Submit Claim" for lecturers, "Approve Claims" for coordinators/managers). I used a blue-green color scheme for professionalism (blue for trust in forms, green for approval buttons) and Bootstrap for responsive grids, making it mobile-friendly. Forms are simple, with prominent buttons and clear labels to reduce user errors. Assumptions include: users are authenticated via basic sessions (no full security in prototype), claims are monthly with no external API integrations, and the system runs on Windows/macOS with .NET 8+ SDK. Constraints: Limited to .NET Core tools (no third-party paid services), prototype is non-functional (static HTML-like views), database is conceptual only, and development time is capped at 8 days to fit student schedules. These decisions prioritize simplicity and feasibility.

My thought process began with data requirements from the PoE (e.g., claims with hours/rates/documents), leading to UML for structure. Then, I focused on UI to visualize user flows, ensuring the prototype mirrors real-world efficiency in claim processing.

(Word count: 412)

**Footnote:** Grok AI was consulted for initial topic brainstorming and structuring the report only.
## Project Plan

The project plan outlines tasks for developing the prototype over a realistic 8-day timeline (assuming part-time student effort, ~5-6 hours/day). It includes dependencies to ensure sequential progress.

| Task Number | Task Description | Dependencies | Timeline (Days) | Estimated Effort (Hours) |
|-------------|------------------|--------------|-----------------|--------------------------|
| 1 | Analyze requirements from PoE and outline design choices. | None | Day 1 | 4 |
| 2 | Create UML class diagram for database. | Task 1 | Day 2 | 3 |
| 3 | Set up ASP.NET Core MVC project and design non-functional views (GUI prototype). | Task 1 | Days 3-5 | 10 |
| 4 | Write documentation report (400-500 words). | Tasks 2-3 | Day 6 | 5 |
| 5 | Initialize GitHub repo and make 5 commits (e.g., initial setup, UML, views, report, refinements). | All | Days 1-7 | 3 |
| 6 | Review prototype for completeness and refine. | All | Day 8 | 2 |

Total: ~27 hours (within the suggested 45-hour minimum for the full PoE). This plan is achievable by focusing on prototypes without full implementation.