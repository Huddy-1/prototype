using Microsoft.AspNetCore.Mvc;

public class HomeController : Controller
{
    public IActionResult Index() => View(); // Dashboard
    public IActionResult SubmitClaim() => View(); // Lecturer submit
    public IActionResult ApproveClaims() => View(); // Approvals
    public IActionResult UploadDocument() => View(); // Upload
    public IActionResult TrackStatus() => View(); // Tracking
}